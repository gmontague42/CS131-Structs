/******************************************************************************
* Project: Lab2aV1
* File: main.c
* Author: Gwendolyn Montague
* Date: 10/25/2020
* Description: This is a console-based program that uses partially filled
*              parallel arrays to read in user entered names of actors and
*              their birthdays. The program also displays the contents of the
*              array if the user selects to view all entries.
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHOICE_ADD_ACTOR 1
#define CHOICE_VIEW_ACTOR 2
#define MAX_ACTOR_NAMES 100
#define MAX_BIRTH_DETAILS 3

typedef struct actorDetails
{
    char firstName[25];
    char lastName[25];
    int birthDate[MAX_BIRTH_DETAILS];
}actorDetails;


// prototype functions
int mainMenuSelection();
void getActor(actorDetails*, int count);
void viewActors(actorDetails* , int count);
void displayDetails(actorDetails*, int actorSelection);
/******************************************************************************
* Function: main
* Description: Controls the main flow of the program and calls the necessary
*              functions.
******************************************************************************/
int main()
{
    char again = 'N';
    int mainMenu;
    int choice = 0;
    int count;
    int actorSelection;

    struct actorDetails actorList[MAX_ACTOR_NAMES];
    do
    {
        do
        {
            mainMenu = mainMenuSelection();
        }
        while(choice < 0 || choice >= 3);

        switch(mainMenu)
        {
        case 1:
            getActor(actorList, count);
            count++;
            break;
        }
        switch(mainMenu)
        {

        case 2:
            actorSelection = -1;
            viewActors(actorList, count);
            while (actorSelection < 0 || actorSelection > count)
                {
                    printf("%s", "Enter the number for an actor to see their details or 0 to exit to the main menu: ");
                    scanf("%d", &actorSelection);
                    while(getchar() != '\n');
                }
                printf("\n");
                if (actorSelection > 0)
                {
                    displayDetails(actorList, actorSelection - 1);
                }
            break;
        }
        switch(mainMenu)
        {
        case 3:
            return 0;
        }
        printf("Would you like to add another actor? (Y/N): ");
        scanf("%c", &again);
        while (getchar() != '\n');
    }
    while (again == 'Y' || again == 'y');
}
/******************************************************************************
* Function: mainMenuSelection
* Description: This function displays the list of menu options for
*              the user.
* Output: int choice - the number that coincides with the option the user
*         selected.
******************************************************************************/
int mainMenuSelection()
{
    int choice;
    system("CLS");
    printf(" Welcome!\n");
    printf(" 1- Add an actor: \n");
    printf(" 2- View all actors: \n");
    printf(" 3- Exit System: \n");
    printf(" Enter your choice: ");
    scanf("%d", &choice);
    system("CLS");
    return choice;
}
/******************************************************************************
* Function: getActor
* Description: This function asks the user to enter the name of an actor and
*              then scans in their entry and adds it to the array.
* input: char actorNames[] - the partially filled array of actor names.
*        int count - the current count.
******************************************************************************/
void getActor(actorDetails* actorList, int count)
{
    int month;
    int day;
    int year;
    // store actor name in array
    do
    {
        printf("%s", "Actor name: ");
        scanf("%24s", actorList[count].firstName);
        scanf("%24s", actorList[count].lastName);
        while (getchar() != '\n');
    }
    while (strlen(actorList[count].firstName) < 1 || strlen(actorList[count].lastName) < 1);
    //store actor date of birth in array
    do
    {
        printf("%s\n", "Please enter their date of birth: ");
        printf("%s", "Month: ");
        scanf("%2d", &month);
        while (getchar() != '\n');
        printf("%s", "Day: ");
        scanf("%2d", &day);
        while (getchar() != '\n');
        printf("%s", "Year (1700-2020): ");
        scanf("%4d", &year);
        while (getchar() != '\n');
    }
    while ((month < 0 || month > 12) || (day < 0 || day > 31) || (year < 1700 || month > 2021));
    actorList[count].birthDate[0] = month;
    actorList[count].birthDate[1] = day;
    actorList[count].birthDate[2] = year;
    printf("%s\n", "This actor has been added to the list.");
}
/******************************************************************************
* Function: viewActors
* Description: This function asks the user to enter the number of an actor they
*              would like to see the details for, then scans in their entry.
* input: char actorNames[] - the partially filled array of actor names.
*        int count - the current count.
* output: int selection - the number the user selected to view.
******************************************************************************/
void viewActors(actorDetails* actorList, int count)
{
    for (int i = 0; i < count; i++)
    {
        printf("#%d ", i + 1);
        printf("%s %s\n", actorList[i].firstName, actorList[i].lastName);
    }
}
/******************************************************************************
* Function: displayDetails
* Description: This function prints to screen the actor details the user
*              selected to view.
* input: char name[] - the name of the actor.
*        int birthDate - the birthday of the selected actor.
******************************************************************************/
void displayDetails(actorDetails* actorList, int selection)
{
    printf(" %s %s\n", actorList[selection].firstName, actorList[selection].lastName);
    printf(" Date of birth: %d/%d/%d\n", actorList[selection].birthDate[0], actorList[selection].birthDate[1], actorList[selection].birthDate[2]);
}
